
#include <bits/stdc++.h>
using namespace std;

map<int, long long> parseJsonFile(const string& filename, int& k) {
    ifstream file(filename);
    map<int, long long> shares;
    string line;
    k = 0;

    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        exit(1);
    }

    while (getline(file, line)) {
        line.erase(remove_if(line.begin(), line.end(), ::isspace), line.end());

        if (line.find("\"k\"") != string::npos) {
            auto pos = line.find(":");
            k = stoi(line.substr(pos + 1, line.find(",") - pos));
        } else if (isdigit(line[1])) {
            int x = stoi(line.substr(1, line.find("\"", 1) - 1));
            getline(file, line);
            int base = stoi(line.substr(line.find(":") + 2, line.find(",") - line.find(":") - 2));

            getline(file, line);
            string valStr = line.substr(line.find(":") + 2);
            valStr.erase(remove(valStr.begin(), valStr.end(), '\"'), valStr.end());
            valStr.erase(remove(valStr.begin(), valStr.end(), ','), valStr.end());

            long long y = stoll(valStr, nullptr, base);
            shares[x] = y;
        }
    }

    file.close();
    return shares;
}

long long lagrangeInterpolation(const map<int, long long>& shares, int k) {
    vector<pair<int, long long>> points(shares.begin(), shares.end());
    long long result = 0;

    for (int i = 0; i < k; ++i) {
        long long xi = points[i].first;
        long long yi = points[i].second;

        long double term = yi;
        for (int j = 0; j < k; ++j) {
            if (i == j) continue;
            long long xj = points[j].first;

            term *= (0.0 - xj) / (xi - xj);
        }
        result += round(term);
    }

    return result;
}

int main() {
    vector<string> testcases = {"testcase1.json", "testcase2.json"};

    for (const auto& file : testcases) {
        int k = 0;
        map<int, long long> shares = parseJsonFile(file, k);

        if ((int)shares.size() < k) {
            cout << "Not enough points to reconstruct polynomial for " << file << endl;
            continue;
        }

        long long secret = lagrangeInterpolation(shares, k);
        cout << "Secret from " << file << ": " << secret << endl;
    }

    return 0;
}
